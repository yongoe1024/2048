﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2048
{
    //定义 移动方向 枚举类型
    enum MoveDirection:int
    {
        //******定义值*******
        Up,
        Down,
        Left,
        Right
    }
}
